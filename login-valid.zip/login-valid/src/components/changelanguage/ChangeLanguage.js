import React from 'react'
import { useTranslation } from 'react-i18next';
import './ChangeLanguage.css';

export default function ChangeLanguage() {
    const { i18n } = useTranslation()

    const changeLang = lng => {
        i18n.changeLanguage(lng)
    }


    return (
        <div className="box1">
            <button onClick={() => changeLang('de')}><h2>de</h2></button>
            <button onClick={() => changeLang('en')}><h2>en</h2></button>
        </div>
    )
}
