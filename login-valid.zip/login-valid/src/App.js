import React,{ Suspense } from 'react';
import logo from './logo.svg';
import './App.css';
import Authenticationpage from './page/Authenticationpage' 

function App() {
  return (
    <Suspense fallback={<div>loading...</div>}>
      <Authenticationpage/>
    </Suspense>
  );
}

export default App;
